#ifndef _DFS_H
#define _DFS_H

#include "cs4050.h"

#ifdef __cplusplus
extern "C" 
{
#endif
void PrintDFS(Vertex * V, int countV, Edge * E, int countE);
#ifdef __cplusplus
}
#endif

#endif
